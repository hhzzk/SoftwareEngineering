This is a menu module. You can use it to build a command menu list.

You can get detail usages from the demo.c 

Build Procedure
    $ gcc linktable.c menu.c demo.c -o demo
    $ ./demo # you can input cmd that you added.
